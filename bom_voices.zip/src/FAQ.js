const FAQ = () => {
  return (  
    <div className="content">
      <h2>FAQ</h2>
    </div>
  );
}
 
export default FAQ;