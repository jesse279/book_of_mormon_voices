const Speakers = () => {
  return ( 
    <div>
      <h2>Speakers</h2>
      <div>
        
      </div>
    </div>
   );
}
 
export default Speakers;